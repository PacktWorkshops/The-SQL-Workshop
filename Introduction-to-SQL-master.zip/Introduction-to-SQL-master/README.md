# Introduction-to-SQL

The SCRIPTS directory has two subdirectories

/MYSQL SCRIPTS

/SQL SERVER SCRIPTS

and each of these subdirectories has two files. One file builds the appropriate PACKT ONLINE SHOP database structure - tables, columns, relations - for MySQL or SQL Server, and one file inserts MySQL or SQL Server data rows into the appropriate database structure.
